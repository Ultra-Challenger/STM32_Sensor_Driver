/*********************************************************************************
 * �ļ���  ��main.c
 * ����    ��CO2ģ��
 * ʵ��ƽ̨��STM32F103C8T6
 * ����    ��2018.07.19
**********************************************************************************/

/* ����ͷ�ļ� ----------------------------------------------------------------*/
#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "pm2_5.h"




 int main(void)
 {	
	
   delay_init(72);
	 NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	 uart_init(115200);
	 USART2_Init(9600);
	 delay_ms(1000);	
   while(1)
	 {		

		 printf("PM2.5=  %.1f ug/m^3 \r\n",PM25_ave);
		 delay_ms(1000);	

   }

}
/******************* (C) COPYRIGHT 2018 NTU *****END OF FILE****/
 
    
/*********************/
#include "delay.h"
#include "usart.h"
#include "stdio.h" 
#include "bmp280.h"
#include "bmp280_support.h"
/*********************/
extern void cfg_timer(void); 
u32 temp,press;
int main(void)  
{    
    delay_init(72); 
    uart_init(9600);       
    IIC_Init();
    bmp280_data_readout_template(&temp,&press); 
    cfg_timer();
    while(1)
    {
        printf(" %.2f hPa  \r\n",0.01*press);
        delay_ms(500);
			  delay_ms(500);
    }
}  





















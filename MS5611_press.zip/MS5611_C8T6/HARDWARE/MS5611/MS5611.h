#ifndef __MS5611_H_
#define __MS5611_H_

#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "myiic.h"

u8  MS5611_init(void);
void MS561101BA_getPressure(void);
void MS561101BA_getTemperature(void);
void MS561101BA_RESET(void);

u32 MS561101BA_getConversion(u8 command);
void MS561101BA_GetTemperature(void);

void MS5611_DataShow(void);

extern float dT,TEMP;
extern u32 Pressure;
extern s16 temperature;
extern u16  Cal_C[7];

#endif


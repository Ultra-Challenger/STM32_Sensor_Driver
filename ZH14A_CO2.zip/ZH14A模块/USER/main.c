/*********************************************************************************
 * �ļ���  ��main.c
 * ����    ��CO2ģ��
 * ʵ��ƽ̨��STM32F103C8T6
 * ����    ��2018.07.19
**********************************************************************************/

/* ����ͷ�ļ� ----------------------------------------------------------------*/
#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "CO2.h"




 int main(void)
 {	
   delay_init(72);
	 NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	 uart_init(9600);
	 USART2_Init(9600);

		while(1)
		{
			CO2_Tx();
			printf("CO2=  %d ppm \r\n",CO2_data);
			delay_ms(1000);	
		}

 }


/******************* (C) COPYRIGHT 2018 NTU *****END OF FILE****/
 
    
#ifndef __LED_H
#define __LED_H	 
#include "sys.h"




#define LED13 PCout(13)// PC13

void LED_Init(void);//��ʼ��

		 				    
#endif

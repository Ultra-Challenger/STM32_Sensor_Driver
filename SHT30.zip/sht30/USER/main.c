#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "myiic.h"
#include "sht30.h"

float tem ;
float hum ;
float CO2=451;
float pm25=159;
unsigned char dat[5] = {0};

 int main(void)
 {
	  
		
	  delay_init(72);	          //��ʱ��ʼ��
		NVIC_Configuration();
		uart_init(9600);         	//��ʼ�����ڲ�����Ϊ9600
		IIC_Init();
		 while(1)
		 {          
				
			Read_sht30();
      Convert_sht30();
		//	printf("temp=%.1f;hump=%.1f\r\n",tem,hum);
			 printf("temp=%.1f\r\n",tem);
			 printf("humd=%.1f\r\n",hum);
			 printf("CO22=%.1f\r\n",CO2);
			 printf("PM25=%.1f\r\n",pm25);
//			 printf("%.1f,%.1f,%d,%d\r\n",tem,hum,CO2,pm25);
			 
			LED0=!LED0;	 
			delay_ms(1000);	
			tem = 0;
			hum =0;
			//CO2 =0;
			//pm25 =0;
		 }  
	 
	
 }

